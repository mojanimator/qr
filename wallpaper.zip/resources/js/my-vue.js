// import reportsForm from './components/reports-form.vue'
import imageUploader from './components/image-uploader.vue'


Vue.config.devtools = false;
Vue.config.debug = false;
Vue.config.silent = true;
const app = new Vue({
    el: '#app',
    mode: 'production',

    components: {
        imageUploader

    }
});
