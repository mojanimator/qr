<?php

namespace App\Http\Controllers;

use App\Doc;
use App\Group;
use App\Hooze;
use App\Http\Requests\HoozeRequest;
use App\Http\Requests\SchoolRequest;
use App\Koochro;
use App\Report;
use App\Saabet;
use App\School;
use App\Setting;
use Carbon\Carbon;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Morilog\Jalali\CalendarUtils;
use function Sodium\increment;


class DocController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['search']);
    }

    public function search(Request $request)
    {
//        $query = Report::query();
        $request->validate($request, [
            'group_id' => 'required|number',
            'paginate' => 'sometimes|number',
            'page' => 'sometimes|number',
        ], []);

        $paginate = $request->paginate;
        $page = $request->page;
        $group_id = $request->group_id;


        if (!$paginate) {
            $paginate = 15;
        }
        if (!$page) {
            $page = 1;
        }

        return Doc::where('group_id', $group_id)->paginate($paginate, ['*'], 'page', $page);
    }

    public function groups(Request $request)
    {
//        $query = Report::query();


        return Group::all();
    }

    public function create(Request $request)
    {
        $request->validate([
            'group_id' => 'required|numeric',
//            'doc' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:4096'
            'doc' => 'required|base64_image|base64_size:4096'
        ]);

        DB::transaction(function () use ($request) {

//            $filenameWihExt = $request->file('doc')->getClientOriginalName();
//            $filename = pathinfo($filenameWihExt, PATHINFO_FILENAME);
//            $ext = $request->file('doc')->getClientOriginalExtension();
//            $filenameToStore = $request->group_id . '-' . $filename . '-' . time() . '-' . $ext;
////        $path = $request->file->storeAs($folder, $name . '.' . $uploadedFile->getClientOriginalExtension(), $disk);
//            Storage::disk('public')->put($request->group_id . '/' . $filenameToStore, $request->file);

            $image_parts = explode(";base64,", $request->doc);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_base64 = base64_decode($image_parts[1]);
//            $path = $request->group_id . '/';
            $size = strlen($image_base64) / 1024; //kb

            $doc = Doc::create(['group_id' => $request->group_id, 'path' => '', 'size' => $size]);
            $filenameToStore = 'fashion-' . $doc->id . '.' . $image_type_aux[1];
            $doc->path = $filenameToStore;
            $doc->save();
            $visibility = 'private';
            Storage::disk('public')->put($request->group_id . '/' . $filenameToStore, $image_base64, $visibility);


            Group::where('id', $request->group_id)->increment('num', 1);
            Setting::where('key', 'images')->increment('value', 1);

        });
        return 200;
//        return abort(500, 'error in creating doc!');
    }

    public function fileStorageServe($file)
    {
        // know you can have a mapping so you dont keep the sme names as in local (you can not precsise the same structor as the storage, you can do anything)

        // any permission handling or anything else

        // we check for the existing of the file
        if (!Storage::disk('local')->exists($filePath)) { // note that disk()->exists() expect a relative path, from your disk root path. so in our example we pass directly the path (/.../laravelProject/storage/app) is the default one (referenced with the helper storage_path('app')
            abort('404'); // we redirect to 404 page if it doesn't exist
        }
        //file exist let serve it

// if there is parameters [you can change the files, depending on them. ex serving different content to different regions, or to mobile and desktop ...etc] // repetitive things can be handled through helpers [make helpers]

        return response()->file(storage_path('app' . DIRECTORY_SEPARATOR . ($filePath))); // the response()->file() will add the necessary headers in our place (no headers are needed to be provided for images (it's done automatically) expected hearder is of form => ['Content-Type' => 'image/png'];

// big note here don't use Storage::url() // it's not working correctly.
    }

    public function getCompaniesLogo($file)
    {
        // know you can have a mapping so you dont keep the sme names as in local (you can not precsise the same structor as the storage, you can do anything)

        // any permission handling or anything else

        $filePath = config('fs.gallery') . DIRECTORY_SEPARATOR . $file; // here in place of just using 'gallery', i'm setting it in a config file

        // here i'm getting only the path from the root  (this way we can change the root later) / also we can change the structor on the store itself, change in one place config.fs.

        // $filePath = Storage::url($file); <== this doesn't work don't use

        // check for existance
        if (!Storage::disk('local')->exists($file)) { // as mentionned precise relatively to storage disk root (this one work well not like Storage:url()
            abort('404');
        }

        // if there is parameters [you can change the files, depending on them. ex serving different content to different regions, or to mobile and desktop ...etc] // repetitive things can be handled through helpers [make helpers]

        return response()->file(storage_path('app' . DIRECTORY_SEPARATOR . ($file))); // the response()->file() will add the necessary headers in our place
    }
}
