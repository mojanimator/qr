<?php

use App\Comment;
use App\Group;
use App\Post;
use App\Setting;
use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

//        Post::truncate();
//        Comment::truncate();
//        Group::truncate();
        User::truncate();
        Setting::truncate();

        Group::truncate();


//        factory(Post::class, 20)->create();
//        factory(Comment::class, 40)->create();
//

        DB::table('users')->insert([
            ['id' => 1, 'username' => 'admin', 'email' => 'moj2raj2@gmail.com', 'phone_number' => null,
                'first_name' => 'mojtaba', 'last_name' => 'rajabi', 'password' => '$2y$10$ES608U3ByfwiJlLmoJSYvuScaf2depjcMSk0PBNmCTCMMGX3J6EDW',
                'verified' => '1', 'role' => 'Admin', 'about' => "I'm freelance programmer and designer",
                'img' => "mojtaba.jpg", 'interests' => "['laravel', 'flutter', 'vue', 'football']",
                'likes' => 0, 'dislikes' => 0, 'posts' => 0,
                'token' => bin2hex(openssl_random_pseudo_bytes(30))],

        ]);


        DB::table('settings')->insert([
            ['id' => 1, 'key' => 'images', 'value' => 0], ['id' => 2, 'key' => 'visits', 'value' => 0],]);

        DB::table('groups')->insert([
            ['name' => 'women',], ['name' => 'men',], ['name' => 'child',], ['name' => 'home',],]);

    }
}
