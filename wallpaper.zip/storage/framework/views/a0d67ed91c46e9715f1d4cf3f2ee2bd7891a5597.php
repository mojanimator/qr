<?php if(session()->has('flash_message')): ?>
    <script>


        swal.fire({
            title: "<?php echo e(session('flash_message.title')); ?>",
            text: "<?php echo e(session('flash_message.message')); ?>",
            
            type: "<?php echo e(session('flash_message.level')); ?>",
            cancelButtonText: "باشه",
            cancelButtonColor: '#d33',
            showCancelButton: true,
            showConfirmButton: false,
            showCloseButton: true,
//            timer: 2000,
        })
    </script>

<?php endif; ?>

<?php if(session()->has('flash_message_overlay')): ?>

    <script>


        swal.fire({
            title: "<?php echo e(session('flash_message_overlay.title')); ?>",
            text: "<?php echo e(session('flash_message_overlay.message')); ?>",
            
            type: "<?php echo e(session('flash_message_overlay.level')); ?>",
            cancelButtonText: "باشه",
            cancelButtonColor: '#d33',
            showCancelButton: true,
            showConfirmButton: false,
        })
    </script>

<?php endif; ?><?php /**PATH D:\_laravelProjects\wallpaper\resources\views/flash.blade.php ENDPATH**/ ?>