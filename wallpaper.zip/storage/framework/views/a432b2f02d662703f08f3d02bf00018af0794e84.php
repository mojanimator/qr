<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="canonical" href="https://qr-image-creator.com">
    <meta name="Description" content="Create QR Images For Your Business Freely!">
    <meta name="Keywords" content="create qr, qr, create, free, free qr, free qr creator, business, logo, brand">
    <meta name="Author" content="Mojtaba Rajabi">
    <meta name="Copyright" content="Copyright (c) 2019 by qr-image-creator">
    <meta name="Copyright" content="text/html; charset=unicode">
    
    <meta name="Resource-Type" content="document">
    <meta name="Distribution" content="Global">
    <meta name="Design" content="moj2raj2@gmail.com">
    <meta name="Generator" content="moj2raj2@gmail.com">
    <meta name="Rating" content="General">
    <meta name="icon" content="/img/logo.png">
    <meta name="shortcut icon" content="/img/logo.png">
    <link rel="icon" type="image/png" href="/img/logo.png"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>" type="text/css">
    
    
    
    

<!-- Include a polyfill for ES6 Promises (optional) for IE11 -->

    
    

</head>
<body>


<nav class="navbar navbar-expand-md navbar-dark fixed-top    pt-0 " id="navbar">
    

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
            aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto mx-1">
            <li class="<?php echo e(request()->is('/') ? 'active ':''); ?>nav-item text-center">
                <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
            </li>
            <?php if(auth()->guest()): ?>
                <li class="<?php echo e(request()->is('login') ? 'active ':''); ?>nav-item">
                    <a class="nav-link text-center" href="<?php echo e(url('login')); ?>">Login</a></li>

            <?php else: ?>
                <li class="nav-item dropdown ">
                    <a href="#" class=" nav-link dropdown-toggle" data-toggle="dropdown" role="button"
                       aria-expanded="false">
                        <?php echo e(auth()->user()->username); ?> <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu" role="menu">


                        <li class="nav-item text-center">
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>

                            <a class="nav-link"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                               href="<?php echo e(route('logout')); ?>">
                                Logout <i class="fa   fa-sign-out-alt"></i>
                            </a>
                        </li>


                    </ul>
                </li>
            <?php endif; ?>

        </ul>


    </div>
    <div
            class=" bg-gradient-purple text-white small position-absolute right-0 bottom-0 px-2 mx-2 "><?php echo e(\Carbon\Carbon::now('Asia/Tehran')); ?></div>


</nav>


<section class=" container-full   " id="app">
    <?php echo $__env->yieldContent('content'); ?>
</section>




<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>

</script>
</body>
</html><?php /**PATH D:\_laravelProjects\wallpaper\resources\views/layout.blade.php ENDPATH**/ ?>