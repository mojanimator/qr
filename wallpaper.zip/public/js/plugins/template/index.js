// Exports the "template" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/template')
//   ES2015:
//     import 'tinymce/plugins/template'
require('./plugin.js');