<?php

// resources/lang/en/messages.php

return [
    'register' => 'ثبت نام',
    'username' => 'نام کاربری',
    'name' => 'نام ',
    'family' => 'نام خانوادگی',
    'phone' => 'شماره تماس',
    'mail' => 'ایمیل',
    'password' => 'گذرواژه',
    'confPassword' => 'تایید گذرواژه',
];